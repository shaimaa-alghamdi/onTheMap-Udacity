//
//  tableViewController.swift
//  onTheMap2
//
//  Created by شيما on 19/04/1440 AH .
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import SafariServices


class tableViewController: UITableViewController {

    //outlet
    @IBOutlet var table: UITableView!
    
    //store (ModelDataArray.shared.userDataArray) in variable
    var usersDataArray = ModelDataArray.shared.userDataArray
    
    override func viewWillAppear(_ animated: Bool) {
        //call Alluser Func in viewWillAppear
        Alluser()
    }
    
    
    //MARK: getAllUsersData
    func Alluser(){
        //remove all data in the map & Update data
        usersDataArray.removeAll()
        ActivityIndicator.startActivity(view: view)
      
        
        parseRequest.sharedInstance().getDataFromUsers{(success, data, error) in
            
            if success {
                
                guard let newData = data else {return}
                
                self.usersDataArray = newData as! [Results]
                
                DispatchQueue.main.async {
                    ActivityIndicator.stopActivity()
                    
                    //get all users info
                    self.table.reloadData()
                }
            }
            else {
                DispatchQueue.main.async {
                    ActivityIndicator.stopActivity()
                }
                Alert.BasicAlert(vc: self, message: error!)
            }
        }
    }
    
    
    // Actions
    
    @IBAction func logout(_ sender: Any) {
        //using deleteSession Func .
        request.sharedInstance().deleteSession{(success, data, error) in
            
            DispatchQueue.main.async {
                if success {
                    self.dismiss(animated: true, completion: nil)
                }
                else {
                    Alert.BasicAlert(vc: self, message: error!)
                }
            }
        }
    }
    
    
    // MARK: Table view functions
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return number of rows
        return usersDataArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //use the customized tableCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "usersDataCell") as! cellTableViewCell
        
        cell.fillCell(data: usersDataArray[indexPath.row] as! Results)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let array = usersDataArray as! [Results]
        
        if let urlString = array[indexPath.row].mediaURL, let url = URL(string: urlString) {
            
            //if url begins with http safari page will open . otherwise , show Alert "cannot open"
            if url.absoluteString.hasPrefix("http") {
                let svc = SFSafariViewController(url: url)
                present(svc, animated: true, completion: nil)
            }
            else {
            
                DispatchQueue.main.async {
                    Alert.BasicAlert(vc: self, message: "cann't open")
                
                }
            }
        }
    }
    

 // to Addlocation , call getUserDataByUniqueKey Func.
    @IBAction func add(_ sender: Any) {
        parseRequest.sharedInstance().getUserDataByUniqueKey{(success, data, error) in
            
            if success {

                // defined this identifier in StoryBoard to complete process id data not Empty
                        self.performSegue(withIdentifier: "addLocation", sender: nil)
                }
           
            else {
                Alert.BasicAlert(vc: self, message: error!)
            }
        }

        }
    
       //call Alluser Func
    @IBAction func refresh(_ sender: Any) {
        Alluser()
    }
    
  

}

