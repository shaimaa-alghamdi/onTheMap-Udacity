//
//  parseRequest.swift
//  onTheMap2
//
//  Created by شيما on 01/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation


class parseRequest : NSObject {
    
    //only has ibjectID
    var objectID: String? = nil
    
    override init() {
        super.init()
    }
    
    //MARK: Get Method
    func taskForGetMethod<D: Decodable>(_ method: String, parameters: [String: AnyObject], decode: D.Type, completionHandlerForGet: @escaping(_ result: AnyObject?, _ error: NSError?)-> Void)-> URLSessionTask{
        
        //  Set the parameters
        var paramWithApi = parameters
        
        // Build the request & configure the request
        var request = NSMutableURLRequest(url: URLFromParameters(paramWithApi, withPathExtension: method))
            //.URLFromParameters(paramWithApi, withPathExtension: method))
        
        request.addValue(Constant.ApplicationID, forHTTPHeaderField: ParameterKeys.ApplicationID)
        request.addValue(Constant.ApiKey, forHTTPHeaderField: ParameterKeys.APIKey)
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            func sendError(_ error: String){
                let userInfo = [NSLocalizedDescriptionKey: error]
                completionHandlerForGet(nil, NSError(domain: "taskForGetMethod", code: 1, userInfo: userInfo))
            }
            
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            
            //  Parse the data and use the data (Happens in completion Handler)
            self.converDataWithCompletionHandler(data, decode: decode, completionHandlerForConvertData: completionHandlerForGet)
        }
        
        // Start the request
        task.resume()
        return task
    }
    
    //MARK: Post Method
    func taskForPostMethod<E:Encodable, D: Decodable>(_ method: String, decode: D.Type?, jsonBody: E, completionHandlerForPost: @escaping(_ result: AnyObject?, _ error: NSError?)-> Void) -> URLSessionDataTask{
        
        func sendError(_ error: String) {
            let userInfo = [NSLocalizedDescriptionKey : error]
            completionHandlerForPost(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: userInfo))
        }
        
        //  Build the URL & configure the request
        let request = NSMutableURLRequest(url: URLWithoutParameters(withPathExtension: method))
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(Constant.ApplicationID, forHTTPHeaderField: ParameterKeys.ApplicationID)
        request.addValue(Constant.ApiKey, forHTTPHeaderField: ParameterKeys.APIKey)
        
        do{
            let JsonBody = try JSONEncoder().encode(jsonBody)
            request.httpBody = JsonBody
        }
        catch{
            sendError("There was an error with your request: \(error)")
        }
        
        //  Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            //  Parse the data & use it
            self.converDataWithCompletionHandler(data, decode: decode!, completionHandlerForConvertData: completionHandlerForPost)
        }
        
        //  Start the request
        task.resume()
        return task
    }
    
    //MARK: Put Method
    func taskForPutMethod<E: Encodable, D:Decodable>(_ method: String, decode: D.Type?, jsonBody: E, completionHandlerForPut: @escaping(_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask{
        
        func sendError(_ error: String) {
            let userInfo = [NSLocalizedDescriptionKey : error]
            completionHandlerForPut(nil, NSError(domain: "taskForPUTMethod", code: 1, userInfo: userInfo))
        }
        
        // Build the URL & Make the request
        let request = NSMutableURLRequest(url: URLWithoutParameters(withPathExtension: method))
        request.httpMethod = HTTPMethod.put.rawValue
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(Constant.ApplicationID, forHTTPHeaderField: ParameterKeys.ApplicationID)
        request.addValue(Constant.ApiKey, forHTTPHeaderField: ParameterKeys.APIKey)
        
        do{
            let JsonBody = try JSONEncoder().encode(jsonBody)
            request.httpBody = JsonBody
        }
        catch{
            sendError("There was an error with your request \(error)")
        }
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            self.converDataWithCompletionHandler(data, decode: decode!, completionHandlerForConvertData: completionHandlerForPut)
        }
        
        // Start the request
        task.resume()
        return task
}


//MARK: converDataWithCompletionHandler
private func converDataWithCompletionHandler<D: Decodable>(_ data: Data, decode: D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void){
    
    do{
        let parsedResult = try JSONDecoder().decode(decode, from: data)
        completionHandlerForConvertData(parsedResult as AnyObject, nil)
    }
    catch {
        let userInfo = [NSLocalizedDescriptionKey: "Couldn't parse data as JSON: \(data)"]
        completionHandlerForConvertData(nil, NSError(domain: "convertDataWithCompletionHandler", code: 1, userInfo: userInfo))
    }
}


//MARK: URLFromParameters
    
    // define the URl to make it unused ASCII
private func URLFromParameters(_ parameters: [String: AnyObject], withPathExtension: String? = nil) -> URL {
    var components = URLComponents()
    components.scheme = Constant.ApiScheme
    components.host = Constant.ApiHost
    components.path = Constant.ApiPath + (withPathExtension ?? "")
    components.queryItems = [URLQueryItem]()
    
    for(key, value) in parameters {
        let queryItem = URLQueryItem(name: key, value: "\(value)")
        components.queryItems!.append(queryItem)
    }
    
    //Returning the url
    let url: URL?
    let urlString = components.url!.absoluteString
    if urlString.contains("%22:") {
        url = URL(string: "\(urlString.replacingOccurrences(of: "%22:", with: "%22%3A"))")
    }
    else {
        url = components.url!
    }
    
    return url!
}

//MARK: URLWithoutParameters
    //just use URLComponents (scheme , host & path)
private func URLWithoutParameters(withPathExtension: String? = nil) -> URL{
    var components = URLComponents()
    components.scheme = Constant.ApiScheme
    components.host = Constant.ApiHost
    components.path = Constant.ApiPath + (withPathExtension ?? "")
    
    return components.url!
}

}
