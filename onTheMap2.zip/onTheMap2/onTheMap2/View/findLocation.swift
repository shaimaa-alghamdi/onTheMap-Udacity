//
//  findLocation.swift
//  onTheMap2
//
//  Created by شيما on 21/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import MapKit


class findLocation: UIViewController {

    
    
    @IBOutlet weak var location: UITextField!
    
    
    
    @IBOutlet weak var urlField: UITextField!
    var latitude: Double?
    var longitude: Double?
    
    func returnToRoot(){
        DispatchQueue.main.async {
            if let navController = self.navigationController {
                navController.popToRootViewController(animated: true)
            }
        }
    }
    
    
    
    
    @IBAction func findButton(_ sender: Any) {
        guard let url = urlField.text else {return}
        
        // checks if link begins with (http) and complete it as the user wants like https
        if url.hasPrefix("http") == false {
            Alert.BasicAlert(vc: self, message: "URL must contain http://")

        }
        else {
            if location.text != "" &&  urlField.text != "" {
                
                ActivityIndicator.startActivity(view: view)
                
                //create search request and start the search on locationTextField
                let searchRequest = MKLocalSearch.Request()
                searchRequest.naturalLanguageQuery = location.text
                
                let activeSearch = MKLocalSearch(request: searchRequest)
                
                //see if there is any error. Otherwise, shows the location
                activeSearch.start{(response, error) in
                    
                    if error != nil {
                        ActivityIndicator.stopActivity()
                        
                        Alert.BasicAlert(vc: self, message: "Location doesn't exist!")
                    }
                    else {
                        ActivityIndicator.stopActivity()
                        
                        self.latitude = response?.boundingRegion.center.latitude
                        self.longitude = response?.boundingRegion.center.longitude
                        //complete , otherwise show Alert "Enter your location and URL!"
                        self.performSegue(withIdentifier: "putlocation", sender: nil)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    Alert.BasicAlert(vc: self, message: "Enter your location and URL!")
             
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "putlocation" {
            
            let vc = segue.destination as! AddViewController
            
            //send data to addLocationViewController
            vc.mapString = location.text
            vc.mediaURL = urlField.text
            vc.latitude = self.latitude
            vc.longitude = self.longitude
        }
    }
}



