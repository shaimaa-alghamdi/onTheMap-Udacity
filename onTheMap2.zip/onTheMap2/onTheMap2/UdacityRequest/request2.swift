//
//  request2.swift
//  onTheMap2
//
//  Created by شيما on 01/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

extension request{
    
//MARK: authenticateWithViewController func

    func authenticateWithViewController<E: Encodable>(_ hostViewController: UIViewController,jsonBody: E, completionHandlerForAuth: @escaping (_ success: Bool, _ error: String?)-> Void){
    
    self.getSession(jsonBody: jsonBody) {(success, sessionId, userId, error) in
        if success {
            self.sessionID = sessionId
            self.userID = userId
            self.getPublicDataForUserId(userId: userId) {(success, nickname, error) in
                if success {
                    
                    if let nickname = nickname {
                        self.nickname = "\(nickname)"
                    }
                }
                
                completionHandlerForAuth(success, error)
            }
        }
        else {
            completionHandlerForAuth(success, error)
        }
    }
}


//MARK: getSession func
private func getSession<E: Encodable>( jsonBody:E ,completionHandlerForSession: @escaping (_ success: Bool , _ sessionID: String?,_ userId: String?, _ error: String?) -> Void){
    
    //2: Make th request
    _ = taskForPostMethod(Methods.AuthenticationSession, decode: UdacitySessionResponse.self, jsonBody: jsonBody) {(result, error) in
        if let error = error {
            completionHandlerForSession(false, nil,nil,"\(error.localizedDescription)")
        }
        else {
            let newResult = result as! UdacitySessionResponse
            if let sessionId = newResult.session.id, let userId = newResult.account.key {
                completionHandlerForSession(true, sessionId, userId, nil)
            }
            else {
                completionHandlerForSession(false, nil, nil, "\(error!.localizedDescription)")
            }
        }
    }
}

//MARK: getPublicDataForUserId
private func getPublicDataForUserId(userId: String?, _ completionHandlerForUserId: @escaping (_ success: Bool, _ nickname: String?, _ error: String?) -> Void){
    
    var mutableMethod: String = Methods.AuthenticationGetPublicDataForUserID
    mutableMethod = substituteKeyInMethod(mutableMethod, key: URLKeys.UserID, value: String(request.sharedInstance().userID!))!
    
    //2: Make the request
    _ = taskForGetMethod(mutableMethod, decode: UdacityUserData.self) {(result, error) in
        if let error = error {
            completionHandlerForUserId(false, nil, "\(error.localizedDescription)")
        }
        else {
            let newResult = result as! UdacityUserData
            if let nickname = newResult.nickname {
                completionHandlerForUserId(true, nickname, nil)
            }
            else {
                completionHandlerForUserId(false, nil, "\(String(describing: error?.localizedDescription))")
            }
        }
    }
}

//MARK: substituteKeyInMethod
func substituteKeyInMethod(_ method: String, key: String, value: String) -> String? {
    if method.range(of: "{\(key)}") != nil {
        return  method.replacingOccurrences(of: "{\(key)}", with: value)
    }
    else {
        return nil
    }
}

//MARK: deleteSession Function
func deleteSession(_ completionHandlerForSession: @escaping (_ success: Bool, _ sessionId: String?, _ error: String?)-> Void) {
    
    _ = taskForDeleteMethod(Methods.AuthenticationSession, decode: SessionDelete.self, completionHandlerForDelete: {(result, error) in
        if let error = error {
            completionHandlerForSession(false, nil, "\(error.localizedDescription)")
        }
        else{
            let newResult = result as! SessionDelete
            if let sessionId = newResult.session.id {
                completionHandlerForSession(true, sessionId, nil)
            }
            else {
                completionHandlerForSession(false, nil, "\(error!.localizedDescription)")
            }
        }
    } ) //taskForGetMethod parameters end
}


//MARK: SharedInstance()
class func sharedInstance() -> request {
    struct Singleton {
        static var sharedInstance = request()
    }
    return Singleton.sharedInstance
}


}

