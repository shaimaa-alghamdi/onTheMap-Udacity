//
//  parseRequest2.swift
//  onTheMap2
//
//  Created by شيما on 19/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation


extension  parseRequest  {
    
    
   
    
    //MARK: getDataFromUsers
    func getDataFromUsers(_ completionHandlerForUserId: @escaping (_ success: Bool, _ userData: [Any]?, _ error: String?) -> Void){
        
        //1: Set the parameters
        let parameters = [ParameterKeys.Limit: ParameterValues.Limit, ParameterKeys.Order: ParameterValues.Order]
        
        //2: Make the request
        _ = taskForGetMethod(Method.StudentLocation, parameters: parameters as [String: AnyObject], decode: StudentLocations.self){ (result, error) in
            
            if let error = error {
                completionHandlerForUserId(false, nil, "\(error.localizedDescription)")
            }
            else {
                let newResult = result as! StudentLocations
                if let usersData = newResult.results {
                    completionHandlerForUserId(true, usersData, nil)
                }
                else {
                    completionHandlerForUserId(false, nil, "\(error!.localizedDescription)")
                }
            }
        }
    }
    
    //MARK: getUserDataByUniqueKey
    func getUserDataByUniqueKey(_ completionHandlerForUserId: @escaping (_ success: Bool, _ objectId: String?, _ error: String?) -> Void){
        
        let method: String = Method.StudentLocation
        
        let newParam = substituteKeyInMethod(ParameterValues.Where, key: URLKey.UserID, value: request.sharedInstance().userID!)!
        
        //1: Set the parameters
        let parameters = [ParameterKeys.Where: newParam]
        
        //2: Make the request
        _ = taskForGetMethod(method, parameters: parameters as [String: AnyObject], decode: StudentLocations.self){ (result, error) in
            
            if let error = error {
                completionHandlerForUserId(false, nil, "\(error.localizedDescription)")
            }
            else {
                let newResult = result as! StudentLocations
                
                if !((newResult.results?.isEmpty)!) {
                    if let userData = newResult.results {
                        if let objectId = userData[0].objectId {
                            parseRequest.sharedInstance().objectID = objectId
                        }
                        
                        completionHandlerForUserId(true, self.objectID, nil)
                    }
                    else {
                        completionHandlerForUserId(false, nil, "\(error!.localizedDescription)")
                    }
                }
                else {
                    completionHandlerForUserId(true, self.objectID, nil)
                }
            }
        }
    }
    
    
    //MARK: postUserLocation
    func postUserLocation<E: Encodable>(jsonBody: E, completionHandlerForSession: @escaping (_ success: Bool, _ error: String?) -> Void){
        
        _ = taskForPostMethod(Method.StudentLocation, decode: StudentLocationsResponse.self
        , jsonBody: jsonBody) {(result, error) in
            if let error = error {
                completionHandlerForSession(false, "\(error.localizedDescription)")
            }
            else {
                if result != nil {
                    completionHandlerForSession(true, nil)
                }
                else {
                    completionHandlerForSession(false, "\(error!.localizedDescription)")
                }
            }
        }
    }
    
    //MARK: putUserLocation
    func putUserLocation<E: Encodable>(jsonBody: E, completionHandlerForSession: @escaping (_ success: Bool, _ error: String?)-> Void){
        
        var mutableMethod: String = Method.StudentLocationUpdate
        mutableMethod = substituteKeyInMethod(mutableMethod, key: URLKey.ObjectId, value: String(self.objectID!))!
        
        //taskForPutMethod
        _ = taskForPutMethod(mutableMethod, decode: StudentLocationsUpdateResponse.self, jsonBody: jsonBody){(result, error) in
            if let error = error {
                completionHandlerForSession(false,"\(error.localizedDescription)")
            }
            else {
                if result != nil {
                    completionHandlerForSession(true, nil)
                }
                else {
                    completionHandlerForSession(false, "\(error!.localizedDescription)")
                }
            }
        }
        
    }
    
    //MARK: substituteKeyInMethod
    func substituteKeyInMethod(_ method: String, key: String, value: String) -> String?{
        
        if method.range(of: "{\(key)}") != nil {
            return method.replacingOccurrences(of: "{\(key)}", with: value)
        }
        else {
            return nil
        }
    }
    
    //MARK: sharedInstance
    class func sharedInstance() -> parseRequest {
        struct Singleton{
            static var sharedInstance = parseRequest()
        }
        return Singleton.sharedInstance
    }
}


