//
//  cellTableViewCell.swift
//  onTheMap2
//
//  Created by شيما on 1/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class cellTableViewCell: UITableViewCell {

   

    @IBOutlet weak var urlLable: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var imageIcone: UIImageView!

func fillCell(data: Results){
    
    if let first = data.firstName, let last = data.lastName, let url = data.mediaURL {
        urlLable.text = "\(url)"
        name.text = "\(first) \(last)"
        
        
       
     
    }
}
}
