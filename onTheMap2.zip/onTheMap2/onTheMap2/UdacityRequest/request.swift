//
//  request.swift
//  onTheMap2
//
//  Created by شيما on 1/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import Foundation
import UIKit

class request : NSObject{
    //If we didn't add NSObject we wouldn't be able to add override init()

    
    
    //has sessionID, userID and nickname
    var sessionID: String? = nil
    var userID: String? = nil
    var nickname: String? = nil
    
    //MARK: Init()
    override init() {
        super.init()
    }
    
    //MARK: taskForGetMethod
    func taskForGetMethod<D: Decodable>(_ method: String, decode: D.Type, completionHandlerForGET: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        //  Build the URL & Configure the request
        let request = NSMutableURLRequest(url: URLWithoutParameters(withPathExtension: method))
        //We didn't use httpMethod because any request is a get by default
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            func sendError(_ error: String) {
                let userInfo = [NSLocalizedDescriptionKey: error]
                completionHandlerForGET(nil, NSError(domain: "taskForGetMethod", code: 1, userInfo: userInfo))
            }
            
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            let range = 5..<data.count
            let newData = data.subdata(in: range)
            // Parse the data and use the data (Happens in completion Handler)
            self.convertDataWithCompletionHandler(newData,decode: decode, completionHandlerForConvertData: completionHandlerForGET)
        }
        
        // start the request
        task.resume()
        
        return task
        
    }
    
    //MARK: POST Method
    func taskForPostMethod<E: Encodable,D:Decodable>(_ method: String, decode: D.Type?, jsonBody: E, completionHandlerForPost: @escaping (_ result: AnyObject?, _ error: NSError?)-> Void) -> URLSessionDataTask{
        
        //sendError Function
        func sendError(_ error: String) {
            let userInfo = [NSLocalizedDescriptionKey: error]
            completionHandlerForPost(nil, NSError(domain: "taskForGetMethod", code: 1, userInfo: userInfo))
        }
        // Set the parameters
        // Build the URL & Configure the request
        let request = NSMutableURLRequest(url: URLWithoutParameters(withPathExtension: method))
        request.httpMethod = HTTPMethod.post.rawValue
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Constent-Type")
        
        //User -> json
        do{
            let JsonBody = try JSONEncoder().encode(jsonBody)
            request.httpBody = JsonBody
        }catch {
            sendError("There was an error with your request \(error)")
        }
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            
            
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            let range = 5..<data.count
            let newData = data.subdata(in: range)
            
            // Parse the data and use the data (Happens in completion Handler)
            self.convertDataWithCompletionHandler(newData,decode: decode!, completionHandlerForConvertData: completionHandlerForPost)
        }
        
        // start the request
        task.resume()
        
        return task
    }
    
    
    //MARK: Delete Method
    func taskForDeleteMethod<D: Decodable>(_ method: String, decode: D.Type?, completionHandlerForDelete: @escaping (_ result: AnyObject?, _ error: NSError?)-> Void) -> URLSessionDataTask {
        //Set the parameters
        
        //sendError Function
        func sendError(_ error: String) {
            let userInfo = [NSLocalizedDescriptionKey: error]
            completionHandlerForDelete(nil, NSError(domain: "taskForDeleteMethod", code: 1, userInfo: userInfo))
        }
        // Build the URL & Configure the request
        let request = NSMutableURLRequest(url: URLWithoutParameters(withPathExtension: method))
        request.httpMethod = HTTPMethod.delete.rawValue
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request as URLRequest) {(data, response, error) in
            
            
            //GUARD: Was there an error?
            guard (error == nil) else {
                sendError("There was an error with your request: \(error!)")
                return
            }
            //GUARD: Did we get a successful 2xx response?
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode < 300 else {
                sendError("Your request returned a status other than 2xx")
                return
            }
            //GUARD: Was there any data returned?
            guard let data = data else {
                sendError("No data was returned by the request")
                return
            }
            
            let range = 5..<data.count
            let newData = data.subdata(in: range)
            self.convertDataWithCompletionHandler(newData, decode: decode!, completionHandlerForConvertData: completionHandlerForDelete)
        }
        
        // Start the request
        task.resume()
        return task
    }
    
    
    //Serialization Step
    private func convertDataWithCompletionHandler<D:Decodable>(_ data: Data,decode: D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
        
        do {
            let parsedResult = try JSONDecoder().decode(decode, from: data)
            completionHandlerForConvertData(parsedResult as AnyObject, nil)
        } catch {
            let userInfo = [NSLocalizedDescriptionKey : "Could not parse the data as JSON: '\(data)'"]
            completionHandlerForConvertData(nil, NSError(domain: "convertDataWithCompletionHandler", code: 1, userInfo: userInfo))
        }
    }
    
    // create a URL from parameters
    private func URLWithoutParameters(withPathExtension: String? = nil) -> URL {
        
        var components = URLComponents()
        components.scheme = Udacity.ApiScheme
        components.host = Udacity.ApiHost
        components.path = Udacity.ApiPath + (withPathExtension ?? "")
        
        return components.url!
}

}
