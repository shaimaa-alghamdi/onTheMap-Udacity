//
// loginViewController.swift
//  onTheMap2
//
//  Created by شيما on 19/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

// SafariServices library: used when we want to open Safari
import SafariServices

class loginViewController : UIViewController {

  
    
    //Outlets
    @IBOutlet weak var Email: UITextField!
    
    
    
    @IBOutlet weak var userPassword: UITextField!
    
    
    
    
    @IBOutlet weak var loginButton: UIButton!
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        Email.text = ""
        userPassword.text = ""
    }
    
    
    //Actions

    //open this link in safari browser
    @IBAction func singup(_ sender: Any) {
   
    let url = URL(string: "https://www.udacity.com/account/auth#!/signup")
        guard let newUrl = url else {return}
        let svc = SFSafariViewController(url: newUrl)
        present(svc, animated: true, completion: nil)
    }


    @IBAction func login(_ sender: Any) {
   
    
        //Check if textField are not empty
        if (Email.text?.isEmpty)! && (userPassword.text?.isEmpty)! {
            Alert.BasicAlert(vc: self, message: "Empty fields are not allowed")
        } else {
            ActivityIndicator.startActivity(view: self.loginButton)

            guard let username = Email.text else {return}
            guard let password = userPassword.text else {return}
            
            //Create a constant that take the user email and password and store it as a udacity session body
            let body = UdacitySessionBody(udacity: UdacityInfo(username: username, password: password))
            loginButton.isEnabled = false
            
            //use authenticateWithViewController Func .
            request.sharedInstance().authenticateWithViewController(self, jsonBody: body) {(success, error) in
                DispatchQueue.main.async {
                    if success {
                        self.loginButton.isEnabled = true
                        
                        ActivityIndicator.stopActivity()
                        //complete login by define Segue Identifier
                    self.performSegue(withIdentifier: "segue", sender: nil)
                    }
                    else {
                        //show Alert if there are problems in login
                        self.loginButton.isEnabled = true
                        ActivityIndicator.stopActivity()
                        Alert.BasicAlert(vc: self, message: error!)
                        
                    }
                }
            }
        }
        
    }
    

}
    
    
    
    
    
    
    
    
    
    
    
    
    
    


