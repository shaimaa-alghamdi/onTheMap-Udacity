//
//  Activity.swift
//  onTheMap2
//
//  Created by شيما on 04/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit


//here implement the Activity Indicator & we can call it to any UI,without rewrite the code..


struct ActivityIndicator {
    private static var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    // proparity of ActivityIndicator

    static func startActivity(view: UIView){
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .gray
        view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
    }
    //To stop ActivityIndicator..

    static func stopActivity(){
        activityIndicator.stopAnimating()
    }
}
