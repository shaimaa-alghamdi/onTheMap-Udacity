//
//  informations.swift
//  onTheMap2
//
//  Created by شيما on 21/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

//Mark: Udacity session JSON Body
//Codable -> encodable, decodable

// Udacity = UdacityInfo
struct UdacitySessionBody : Codable {
    
    let udacity : UdacityInfo
    
}

struct UdacityInfo : Codable {
    let username:String
    let password:String
}

//Mark: Udacity session JSON response
struct UdacitySessionResponse : Codable {
    let account : Account
    let session : Session
    
}

struct Account : Codable {
    let registered : Bool?
    let key : String?
}

struct SessionDelete : Codable {
    let session : Session
}

struct Session : Codable {
    let id : String?
    let expiration : String?
}

//Mark: User data
struct UdacityUserData : Codable {
    let nickname : String?
    
}


