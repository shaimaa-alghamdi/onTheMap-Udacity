//
//  udacityConstants.swift
//  onTheMap2
//
//  Created by شيما on 1/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation


struct Udacity {
    
    
    //Udacity Session Method :To authenticate udacity API request
    static let ApiScheme = "https"
    static let ApiHost = "onthemap-api.udacity.com"
    static let ApiPath = "/v1"
    
}

// MARK: URL Keys
struct URLKeys {
    static let UserID = "id"
}

// MARK: Methods
struct Methods {
    
    
    //POST & Delete Methods
    static let AuthenticationSession = "/session"
    //GET Method
    static let AuthenticationGetPublicDataForUserID = "/users/{id}"
}



enum HTTPMethod: String {
    case post = "POST"
    case delete = "DELETE"
    case put = "PUT"
}
