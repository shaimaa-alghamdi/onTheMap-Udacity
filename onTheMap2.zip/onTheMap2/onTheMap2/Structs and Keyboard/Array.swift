//
//  Array.swift
//  onTheMap2
//
//  Created by شيما on 04/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

class ModelDataArray {
    static let shared = ModelDataArray()
    var userDataArray = [Any?]()
    private init(){}
}
